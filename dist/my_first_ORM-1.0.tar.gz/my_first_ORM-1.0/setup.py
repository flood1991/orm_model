from distutils.core import setup
setup(name='my_first_ORM',
version='1.0',
description='portfolio',
author='Rodion',
author_email='drink2getdrunk91@gmail.com',
url='https://github.com/flood1991/orm_model',
packages=['../'],
)